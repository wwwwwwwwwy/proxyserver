<template>
    <el-dialog title="编辑值"  size="small" ref="box">
        <el-row class="row">
            <el-radio class="radio" :label="0" v-model="info.type" :checked="info.type==0" id="bodyKey">普通值</el-radio>&nbsp;&nbsp;
            <el-radio class="radio" :label="1" v-model="info.type" :checked="info.type==1" id="bodyRaw">状态码映射</el-radio>
        </el-row>
        <el-row class="row" style="height: 100%;overflow-y: auto;margin-top: 20px" v-if="info.type==0">
            <table class="table-hover" style="width: 100%;">
                <tbody>
                <template v-for="(item,index) in info.data">
                    <tr style="text-align: center;vertical-align: middle;height: 50px">
                        <td style="width: 40%;text-align: center;vertical-align: middle;">
                            <el-input style="width: 95%" v-model="item.value" placeholder="请输入可能的值" :disabled="true"></el-input>
                        </td>
                        <td style="width: 60%;text-align: center;vertical-align: middle;">
                            <el-input style="width: 95%" v-model="item.remark" placeholder="请输入备注" :disabled="true"></el-input>
                        </td>
                        </td>
                    </tr>
                </template>
                </tbody>
            </table>
        </el-row>
        <el-row class="row" style="text-align: center;height: 50px;line-height: 50px;margin-top: 20px" v-else>
            <el-col class="col" :span="4">
                状态码
            </el-col>
            <el-col class="col" :span="20">
                <el-select style="width: 90%" v-model="info.status">
                    <el-option value="" label="无"></el-option>
                    <el-option v-for="item in arrStatus" :value="item.id" :label="item.name" :key="item.id"></el-option>
                </el-select>
            </el-col>
        </el-row>
    </el-dialog>
</template>

<script>
    module.exports={
        props:["source"],
        data:function () {
            return {
                info:function () {
                    var obj= $.clone(this.source);
                    if(obj.type==0)
                    {
                        var arr1=[];
                        if(this.source.data.length==0)
                        {
                            arr1.push({
                                value:"",
                                remark:""
                            });
                        }
                        else
                        {
                            arr1=$.clone(this.source.data)
                        }
                        obj.data=arr1;
                    }
                    else
                    {
                        if(!this.source.status)
                        {
                            obj.status="";
                        }
                        else
                        {
                            var bFind=false;
                            var _this=this;
                            this.$store.state.status.forEach(function (obj) {
                                if(obj.id==_this.source.status)
                                {
                                    bFind=true;
                                }
                            })
                            if(bFind)
                            {
                                obj.status= _this.source.status;
                            }
                            else
                            {
                                obj.status=""
                                $.tip("状态码已不存在!",0);
                            }
                        }
                    }
                    return obj;
                }.call(this),
            }
        },
        computed:{
            arrStatus:function () {
                return this.$store.state.status
            }
        },
        methods:{
            remove:function (index) {
                this.info.data.splice(index,1);
            },
        }
    }
</script>
