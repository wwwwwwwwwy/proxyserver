
module.exports={
    baseUrl:"http://"+location.host,
    host:"http://"+location.host
}