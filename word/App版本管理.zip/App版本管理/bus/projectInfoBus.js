/**
* Created by sunxin on 2017/2/23.
*/
module.exports=new Vue();